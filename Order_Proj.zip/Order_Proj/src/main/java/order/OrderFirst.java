package order;

import java.sql.Date;

public class OrderFirst {
	
	private int orderId;
    private String customerName;
	private String productName;
    private Date dom; 
	private int quantity;
    private double price;
    
	public OrderFirst(int orderId, String customerName, String productName, Date dom, int quantity, double price) {
		super();
		this.orderId = orderId;
		this.customerName = customerName;
		this.productName = productName;
		this.dom = dom;
		this.quantity = quantity;
		this.price = price;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Date getDom() {
		return dom;
	}

	public void setDom(Date dom) {
		this.dom = dom;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "OrderFirst [orderId=" + orderId + ", customerName=" + customerName + ", productName=" + productName
				+ ", dom=" + dom + ", quantity=" + quantity + ", price=" + price + "]";
	}
    
}
