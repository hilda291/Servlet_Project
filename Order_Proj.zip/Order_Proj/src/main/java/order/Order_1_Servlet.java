package order;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

//@WebServlet("/Order")
public class Order_1_Servlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String operation = request.getParameter("operation");
        int orderId = Integer.parseInt(request.getParameter("orderId"));
        String customerName = request.getParameter("customerName");
        String productName = request.getParameter("productName");
        String domStr = request.getParameter("dom");
        int quantity = request.getParameter("quantity") == null ? 0 : Integer.parseInt(request.getParameter("quantity"));
        double price = request.getParameter("price") == null ? 0.0 : Double.parseDouble(request.getParameter("price"));
        Date dom = domStr != null && !domStr.isEmpty() ? Date.valueOf(domStr) : null;

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        DataBaseOperation dbOperation = new DataBaseOperation();

        try {
            dbOperation.createTableIfNotExists(); // Ensure table exists before any operation

            switch (operation.toLowerCase()) {
                case "insert":
                    if (customerName == null || productName == null || dom == null) {
                        throw new ServletException("All fields must be filled for insertion.");
                    }
                    OrderFirst order = new OrderFirst(orderId, customerName, productName, dom, quantity, price);
                    dbOperation.insertOrder(order);
                    response.getWriter().println("Order inserted successfully.");
                    out.println("<br>");
                    out.println("<br>");
                    out.println("<form action='view-all-orders'>");
                    out.println("<button type='submit'>View all orders</button>");
                    out.println("</form>");
                    
                    out.println("<br>");
                    out.println("<form action='orderForm.html'>");
                    out.println("<button type='submit'>Back</button>");
                    out.println("</form>");
                    RequestDispatcher rd = request.getRequestDispatcher("order_form");
                    rd.include(request, response);
                    
                    break;

                case "update":
                    if (price == 0) {
                        throw new ServletException("Price must be provided for update.");
                    }
                    dbOperation.updateOrder(orderId, price);
                    response.getWriter().println("Order updated successfully.");
                    out.println("<br>");
                    out.println("<br>");
                    out.println("<form action='view-all-orders'>");
                    out.println("<button type='submit'>View all orders</button>");
                    out.println("</form>");

                    out.println("<br>");
                    out.println("<form action='orderForm.html'>");
                    out.println("<button type='submit'>Back</button>");
                    out.println("</form>");  
                    break;

                case "delete":
                    dbOperation.deleteOrder(orderId);
                   //by me 
//                    response.setContentType("text/html");
//                    PrintWriter out=response.getWriter();
//                    out.print("<a href='view-all-orders'>View all</a>");
//                    out.print("<button>");
//                    response.sendRedirect("orderForm.html");
//                    out.print("</button>");
                    //till here
                    response.getWriter().println("Order deleted successfully.");
                    out.println("<br>");
                    out.println("<br>");
                    out.println("<form action='view-all-orders'>");
                    out.println("<button type='submit'>View all orders</button>");
                    out.println("</form>");       
                    
                    out.println("<br>");
                    out.println("<form action='orderForm.html'>");
                    out.println("<button type='submit'>Back</button>");
                    out.println("</form>");
                
                    break;
                    

                default:
                    throw new ServletException("Invalid operation specified.");
            }
        } catch (SQLException e) {
            throw new ServletException("Database operation failed: " + e.getMessage(), e);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String operation = request.getParameter("operation");
        DataBaseOperation dbOperation = new DataBaseOperation();

        if ("delete".equalsIgnoreCase(operation)) {
            // Extract the 'id' parameter and parse it as an integer
            int orderId = Integer.parseInt(request.getParameter("id"));

            response.setContentType("text/html");
            PrintWriter out = response.getWriter();

            try {
                dbOperation.deleteOrder(orderId); // Pass the orderId to the delete method
                out.println("<html><body>");
                out.println("<h3>Order deleted successfully.</h3>");
                out.println("<a href='view-all-orders'>View All Orders</a>");
                out.println("<br>");
                out.println("<form action='orderForm.html'>");
                out.println("<button type='submit'>Back</button>");
                out.println("</form>");
                out.println("</body></html>");
            } catch (SQLException e) {
                throw new ServletException("Failed to delete order: " + e.getMessage(), e);
            }
        } else {
            // Handle the default view-all-orders operation
            response.setContentType("text/html");
            try (PrintWriter out = response.getWriter()) {
                List<OrderFirst> orders = dbOperation.getAllOrders();
                out.println("<html><head><title>Order List</title></head><body>");
                out.println("<h1>All Orders</h1>");
                out.println("<table border='1'>");
                out.println("<tr><th>Order ID</th><th>Customer Name</th><th>Product Name</th><th>Date of Manufacture</th><th>Quantity</th><th>Price</th><th>Edit</th></tr>");

                for (OrderFirst order : orders) {
                    out.println("<tr>");
                    out.println("<td>" + order.getOrderId() + "</td>");
                    out.println("<td>" + order.getCustomerName() + "</td>");
                    out.println("<td>" + order.getProductName() + "</td>");
                    out.println("<td>" + order.getDom() + "</td>");
                    out.println("<td>" + order.getQuantity() + "</td>");
                    out.println("<td>" + order.getPrice() + "</td>");
                    out.println("<td>");
                    out.println("<form action='delete-order' style='display:inline;' method='get'>");
                    out.println("<input type='hidden' name='operation' value='delete'>");
                    out.println("<input type='hidden' name='id' value='" + order.getOrderId() + "'>");
                    out.println("<button type='submit'>Delete</button>");
                    out.println("</form>");
                    out.println("</td>");
                    out.println("</tr>");
                }

                out.println("</table>");
                out.println("<br>");
                out.println("<form action='orderForm.html'>");
                out.println("<button type='submit'>Back</button>");
                out.println("</form>");
                out.println("</body></html>");
                out.println("</body></html>");
            } catch (SQLException e) {
                throw new ServletException("Failed to retrieve orders: " + e.getMessage(), e);
            }
        }
    }
}

//
//out.println("<br>");
//out.println("<form action='orderForm.html'>");
//out.println("<button type='submit'>Back</button>");
//out.println("</form>"); 
//<form action="view-all-orders" method="get">
//<a href="view-all-orders" class="view-orders">View All Orders</a>
//<button type="submit">Back</button>
//</form>
