package order;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class DataBaseOperation {

    // Create table if not exists
    public void createTableIfNotExists() throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS orders (" +
                     "order_id INT PRIMARY KEY, " +
                     "customer_name VARCHAR(100), " +
                     "product_name VARCHAR(100), " +
                     "dom DATE, " +
                     "quantity INT, " +
                     "price DOUBLE)";
        Connection conn = DBConnection.getConnection();
        Statement stmt = conn.createStatement();
        try{
            stmt.execute(sql);
        }
        finally {
        	stmt.close();
        	conn.close();
        }
    }

    // Insert Operation
    public void insertOrder(OrderFirst orderF) throws SQLException {
        Connection conn = DBConnection.getConnection();
        PreparedStatement stmt = null;
        String sql = "INSERT INTO orders (order_id, customer_name, product_name, dom, quantity, price) VALUES (?, ?, ?, ?, ?, ?)";
        try {
            stmt = conn.prepareStatement(sql); // Assign to stmt
            stmt.setInt(1, orderF.getOrderId());
            stmt.setString(2, orderF.getCustomerName());
            stmt.setString(3, orderF.getProductName());
            stmt.setDate(4, orderF.getDom());
            stmt.setInt(5, orderF.getQuantity());
            stmt.setDouble(6, orderF.getPrice());
            stmt.executeUpdate();
        } finally {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        }
    }

    // Update Operation
    public void updateOrder(int orderId, double price) throws SQLException {
        String sql = "UPDATE orders SET price = ? WHERE order_id = ?";
        Connection conn = DBConnection.getConnection();
        PreparedStatement stmt = null;
        try {
            stmt = conn.prepareStatement(sql); // Assign to stmt
            stmt.setDouble(1, price);
            stmt.setInt(2, orderId);
            stmt.executeUpdate();
        } finally {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        }
    }


 // Delete Operation
    public void deleteOrder(int orderId) throws SQLException {
        Connection conn = DBConnection.getConnection();
        PreparedStatement stmt = null;
        String sql = "DELETE FROM orders WHERE order_id = ?";
        try {
            stmt = conn.prepareStatement(sql); // Assign to stmt
            stmt.setInt(1, orderId);
            stmt.executeUpdate();
        } finally {
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        }
    }


    // Retrieve all orders
    public List<OrderFirst> getAllOrders() throws SQLException {
        String sql = "SELECT * FROM orders";
        Connection conn = DBConnection.getConnection();
        Statement stmt = null;
        ResultSet rs = null;
        List<OrderFirst> orders = new ArrayList<>();
        try {
            stmt = conn.createStatement(); // Properly initialize stmt
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                orders.add(new OrderFirst(
                        rs.getInt("order_id"),
                        rs.getString("customer_name"),
                        rs.getString("product_name"),
                        rs.getDate("dom"),
                        rs.getInt("quantity"),
                        rs.getDouble("price")
                ));
            }
        } finally {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            conn.close();
        }
        return orders;
    }
}
